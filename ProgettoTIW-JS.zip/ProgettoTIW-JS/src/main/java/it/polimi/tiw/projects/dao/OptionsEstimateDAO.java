package it.polimi.tiw.projects.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import it.polimi.tiw.projects.beans.Option;

public class OptionsEstimateDAO {
	private Connection con;

	public OptionsEstimateDAO(Connection connection) {
		this.con = connection;
	} 
	
	public void addOptionsToEstimate(int idEst, int optionId[]) throws SQLException{
	    // the mysql insert statement
	    String query = " INSERT into optionsEstimate (estimateId, optionId) VALUES (?, ?)";
	    // create the mysql insert preparedstatement
	    int i=0;
	    try (PreparedStatement pstatement = con.prepareStatement(query);) {
	        while(i < optionId.length)
	        {	       
	        	pstatement.setInt (1, idEst);
	        	pstatement.setInt (2, optionId[i]);
	        	pstatement.executeUpdate();
	        	i=i+1;
	        }
	    }
	}

	public List<Option> findEstimateOptions(int idEst) throws SQLException{
		List<Option> options = new ArrayList<Option>();
		String query = " SELECT * FROM options AS O , optionsEstimate AS OE WHERE OE.optionId = O.idOption AND OE.estimateId = ?";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, idEst);
			try (ResultSet result = pstatement.executeQuery();) {
				while (result.next()) {
					Option option = new Option();
					option.setIdOption(result.getInt("idOption"));
					option.setCodeOpt(result.getString("codeOpt"));
					option.setType(result.getString("type"));
					option.setName(result.getString("name"));
					options.add(option);
				}
			}
		}
		return options;
	}

}
