package it.polimi.tiw.projects.controllers;

import java.io.IOException;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.polimi.tiw.projects.beans.Option;
import it.polimi.tiw.projects.beans.Product;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.dao.AvailabilityDAO;
import it.polimi.tiw.projects.dao.EstimateDAO;
import it.polimi.tiw.projects.dao.OptionsEstimateDAO;
import it.polimi.tiw.projects.dao.ProductDAO;
import it.polimi.tiw.projects.utils.ConnectionHandler;

@WebServlet("/CreateEstimate")
@MultipartConfig
public class CreateEstimate extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	
	public CreateEstimate() {
		super();
	}
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession s = request.getSession();
		if (s.isNew() || s.getAttribute("user") == null) {
			String loginpath = getServletContext().getContextPath() + "/index.html";
			response.sendRedirect(loginpath);
			return;
		}
		boolean isBadRequest = false;
		User u = (User) s.getAttribute("user");
		String[] opts = request.getParameterValues("option");	
		String prdId = request.getParameter("product");
		if (opts == null || prdId == null) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing parameter for estimate creation");
			return;
		}
		
		
		int[] optionsId = new int[opts.length];
		int productId = 0;
		try {
			int i = 0;
			while(i < opts.length)
			{
				optionsId[i] = Integer.parseInt(opts[i]);
				i=i+1;
			}
			isBadRequest = opts.length < 1 || prdId.isEmpty();			
		} catch (NumberFormatException e) {
			isBadRequest = true;
			e.printStackTrace();
		}
		if (isBadRequest) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().println("Incorrect or missing param values");
			return;
		}
		try {
			productId = Integer.parseInt(prdId);
		} catch (NumberFormatException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Bad product parameter in estimate creation");
			return;
		}
		
		boolean check = false;
		ProductDAO productDao = new ProductDAO(connection) ;
		try {
			List<Product> products = productDao.getAllProducts();			
			for (Product prd : products) {
				if(prd.getIdProduct() == productId)
					check = true;
			}
			if(check == false) {
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.getWriter().println("Incorrect param values");
				return;
			}
			
		} catch (SQLException e) {
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().println("Not possible to create estimate");
			return;
		}
		
		EstimateDAO estimateDao = new EstimateDAO(connection);
		OptionsEstimateDAO optsEstimateDao= new OptionsEstimateDAO(connection);
		AvailabilityDAO availabilityDao = new AvailabilityDAO(connection);
	
		int idEstimate = 0;
		try {
			List<Option> options = availabilityDao.findProductOptions(productId);
			for (int i = 0; i<optionsId.length; i++) {
				check = false;
				for (Option op : options) {
					if(op.getIdOption() == optionsId[i])
						check = true;
				}
				if (check == false) {
					response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
					response.getWriter().println("Incorrect param values");
					return;
				}
			}

		} catch (SQLException e) {
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().println("Not possible to create estimate");
			return;
		}
		
		try {
			estimateDao.createEstimate(productId, u.getIdUser());
		} catch (SQLException e) {
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().println("Not possible to create estimate");
			return;	
		}
		
		try {
			idEstimate = estimateDao.searchLastEstimate(u.getIdUser());
		} catch (SQLException e) {
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().println("Not possible to create estimate");
			return;	
		}
		
		try {
			optsEstimateDao.addOptionsToEstimate(idEstimate, optionsId);
		} catch (SQLException e) {
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().println("Not possible to create estimate");
			return;	
		}
		response.setStatus(HttpServletResponse.SC_OK);
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().print(idEstimate);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

}
