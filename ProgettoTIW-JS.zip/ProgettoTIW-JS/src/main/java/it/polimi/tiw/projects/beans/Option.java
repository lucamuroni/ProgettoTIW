package it.polimi.tiw.projects.beans;

public class Option {
	private int idOption;
	private String codeOpt;
	private String type;
	private String optionName;
	
	public int getIdOption() {
		return idOption;
	}
	public String getCodeOpt() {
		return codeOpt;
	}
	public String getType() {
		return type;
	}
	public String getOptionName() {
		return optionName;
	}
	public void setIdOption(int idOption) {
		this.idOption = idOption;
	}
	public void setCodeOpt(String codeOpt) {
		this.codeOpt = codeOpt;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setName(String optionName) {
		this.optionName = optionName;
	}
}
