package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.polimi.tiw.projects.beans.Estimate;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.dao.EstimateDAO;
import it.polimi.tiw.projects.utils.ConnectionHandler;

@WebServlet("/AddPrice")
@MultipartConfig
public class AddPrice extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	
	public AddPrice() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		int estimateId = 0;
		float price;
		try {
			estimateId = Integer.parseInt(request.getParameter("estimateId"));
			price = Float.parseFloat(request.getParameter("price"));
			if (price <= 0) {
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.getWriter().println("Incorrect param values");
				return;
			}
		} catch (NullPointerException e) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			//System.out.println(estimateId);
			response.getWriter().println("Qui");
			return;
		}
		
		EstimateDAO estimateDAO = new EstimateDAO(connection);
		boolean check = false;	
		List<Estimate> estimates = null;
		try {
			estimates = estimateDAO.findFreeEstimates();
			for(Estimate estimate: estimates) {
				if(estimate.getIdEstimate() == estimateId) {
					check = true;
				}
			}
			if(check == false) {
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.getWriter().println("Incorrect param values");
				return;
			}
			
		} catch(SQLException e){
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().println("Incorrect or missing param values");
			return;
		}
		
		try {
			estimateDAO.addPriceEmployee(user.getIdUser(), price, estimateId);
			
		} catch (SQLException e) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().println("Incorrect or missing param values");
			return;
		}
		
	}
	
	public void destroy() {
		try {
			ConnectionHandler.closeConnection(connection);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
