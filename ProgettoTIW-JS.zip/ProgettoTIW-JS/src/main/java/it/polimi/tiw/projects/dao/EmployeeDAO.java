package it.polimi.tiw.projects.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import it.polimi.tiw.projects.beans.Estimate;

public class EmployeeDAO {
	private Connection con;
	private int id;

	public EmployeeDAO(Connection connection, int id) {
		this.con = connection;
		this.id = id;
	}
	
	public List<Estimate> findfreeEstimates() throws SQLException {
		List<Estimate> freeEstimates = new ArrayList<Estimate>();
		String query = " SELECT * FROM estimate WHERE idEmpoloyee NOT IN (SELECT * FROM estimate AS e1 WHERE e1.price > 0)"; 
		//TODO: insert default value 0 in db.estimate.price
		ResultSet result = null;
		PreparedStatement pstatement = null;
		try {
			pstatement = con.prepareStatement(query);

			result = pstatement.executeQuery();
			
			while (result.next()) {
				Estimate estimate = new Estimate();
				estimate.setIdEstimate(result.getInt("idEstimate"));
				estimate.setIdClient(result.getInt("idClient"));
				estimate.setIdEmployee(000); 
				//000 � rappresentativo del fatto che non esiste ancora un employee associato a questo preventivo
				estimate.setIdProduct(result.getInt("idProduct"));
				estimate.setPrice(result.getInt("price"));

				freeEstimates.add(estimate);
			}
		} catch (SQLException e) {
			throw e;

		} finally {
			try {
				if (result != null)
					result.close();
			} catch (SQLException e1) {
				throw e1;
			}
			try {
				if (pstatement != null)
					pstatement.close();
			} catch (SQLException e2) {
				throw e2;
			}
		}
		return freeEstimates;
	}
	
	public List<Estimate> findEmployeeEstimates() throws SQLException {
		List<Estimate> employeeEstimates = new ArrayList<Estimate>();
		String query = " SELECT * FROM estimate WHERE idEmployee = ?";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, this.id);
			try (ResultSet result = pstatement.executeQuery();) {
				while (result.next()) {
					Estimate estimate = new Estimate();
					estimate.setIdEstimate(result.getInt("idEstimate"));
					estimate.setIdClient(result.getInt("idClient"));
					estimate.setIdEmployee(this.id);
					estimate.setIdProduct(result.getInt("idProduct"));
					estimate.setPrice(result.getInt("price"));
					employeeEstimates.add(estimate);
				}
			}
		}
		return employeeEstimates;
	}
}
