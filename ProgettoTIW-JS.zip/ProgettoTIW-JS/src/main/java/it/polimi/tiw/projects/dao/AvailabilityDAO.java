package it.polimi.tiw.projects.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import it.polimi.tiw.projects.beans.Option;

public class AvailabilityDAO {
	private Connection con;

	public AvailabilityDAO(Connection connection) {
		this.con = connection;
	}

	public List<Option> findProductOptions(int idProd) throws SQLException{
		List<Option> options = new ArrayList<Option>();
		String query = " SELECT O.idOption, O.codeOpt, O.type, O.name FROM availability A JOIN options O ON A.codeOption = O.idOption WHERE A.codeProduct = ? ";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, idProd);
			try (ResultSet result = pstatement.executeQuery();) {
				while (result.next()) {
					Option option = new Option();
					option.setIdOption(result.getInt("idOption"));
					option.setCodeOpt(result.getString("codeOpt"));
					option.setType(result.getString("type"));
					option.setName(result.getString("name"));
					options.add(option);
				}
			}
		}
		return options;
	}

}
