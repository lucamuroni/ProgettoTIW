{
	let estimateDetails, estimatesList, wizard, pageOrchestrator = new PageOrchestrator();
	
	function getAllProductsOptions() {
		makecall("GET", "GetProductsData", null, 
		function(req) {
			if (req.readyState == 4) {
	            var message1 = req.responseText;
	            if (req.status == 200) {
	              var productsToShow = JSON.parse(req.responseText);
	              for(var i = 0; i<producstToShow.lenght; i++)
	              {
					makecall("Get", "GetProductOptions?productsid="+i, null,
					function(x) {
						if (x.readyState == 4) {
	            			var message2 = req.responseText;
	            			if (req.status == 200) {
								//TODO: qui bisogna creare l'Array di opzioni
							}
						}
				  	});
	              }
	            } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
            	} else {
	            self.alert.textContent = message;
	        	}
	        }
	    });
	}
	
	window.addEventListener("load", () => {
	    if (sessionStorage.getItem("username") == null) {
	      window.location.href = "index.html";
	    } else {
	      pageOrchestrator.start(); // initialize the components
	      pageOrchestrator.refresh();
	    } // display initial content
	    
	}, false);
	
	// Constructors of view components
	
	function PersonalMessage(_username, messagecontainer) {
	    this.username = _username;
	    this.show = function() {
	      messagecontainer.textContent = this.username;
	    }
	}
	
	function EstimatesList(_alert, _listcontainer, _listcontainerbody) {
	    this.alert = _alert;
	    this.listcontainer = _listcontainer;
	    this.listcontainerbody = _listcontainerbody;

	    this.reset = function() {
	      this.listcontainer.style.visibility = "hidden";
	    }

	    this.show = function(next) {
	      var self = this;
	      makeCall("GET", "GetMissionsData", null,
	        function(req) {
	          if (req.readyState == 4) {
	            var message = req.responseText;
	            if (req.status == 200) {
	              var missionsToShow = JSON.parse(req.responseText);
	              if (missionsToShow.length == 0) {
	                self.alert.textContent = "No missions yet!";
	                return;
	              }
	              self.update(missionsToShow); // self visible by closure
	              if (next) next(); // show the default element of the list if present
	            
	          } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
                  }
                  else {
	            self.alert.textContent = message;
	          }}
	        }
	      );
	    };


	    this.update = function(arrayMissions) {
	      var elem, i, row, destcell, datecell, linkcell, anchor;
	      this.listcontainerbody.innerHTML = ""; // empty the table body
	      // build updated list
	      var self = this;
	      arrayMissions.forEach(function(mission) { // self visible here, not this
	        row = document.createElement("tr");
	        destcell = document.createElement("td");
	        destcell.textContent = mission.destination;
	        row.appendChild(destcell);
	        datecell = document.createElement("td");
	        datecell.textContent = mission.startDate;
	        row.appendChild(datecell);
	        linkcell = document.createElement("td");
	        anchor = document.createElement("a");
	        linkcell.appendChild(anchor);
	        linkText = document.createTextNode("Show");
	        anchor.appendChild(linkText);
	        //anchor.missionid = mission.id; // make list item clickable
	        anchor.setAttribute('missionid', mission.id); // set a custom HTML attribute
	        anchor.addEventListener("click", (e) => {
	          // dependency via module parameter
	          missionDetails.show(e.target.getAttribute("missionid")); // the list must know the details container
	        }, false);
	        anchor.href = "#";
	        row.appendChild(linkcell);
	        self.listcontainerbody.appendChild(row);
	      });
	      this.listcontainer.style.visibility = "visible";

	    }

	    this.autoclick = function(missionId) {
	      var e = new Event("click");
	      var selector = "a[missionid='" + missionId + "']";
	      var anchorToClick =  // the first mission or the mission with id = missionId
	        (missionId) ? document.querySelector(selector) : this.listcontainerbody.querySelectorAll("a")[0];
	      if (anchorToClick) anchorToClick.dispatchEvent(e);
	    }

	  }
	
	function PageOrchestrator() {
		var alertContainer = document.getElementById("id_alert");
	    
	    this.start = function() {
	      personalMessage = new PersonalMessage(sessionStorage.getItem('username'),
	        document.getElementById("id_username"));
	      personalMessage.show();
		}
	}
}