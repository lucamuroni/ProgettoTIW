/**
 * Login management
 */

(function() { // avoid variables ending up in the global scope

	function validateEmail(elementValue){      
   		var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
   		return emailPattern.test(elementValue); 
 	} 
  	document.getElementById("loginbutton").addEventListener('click', (e) => {
	var form = e.target.closest("form");
	var input = document.getElementById("name").value;
	var bool = validateEmail(input);
	if(!bool && form.checkValidity()) {
		document.getElementById("errormessage").textContent = "Incorrect mail format";
	} else if (form.checkValidity()) {
      makeCall("POST", 'CheckLogin', e.target.closest("form"),
        function(x) {
          if (x.readyState == XMLHttpRequest.DONE) {
            var message = x.responseText;
            switch (x.status) {
              case 200:
            	sessionStorage.setItem('username', message);
                window.location.href = "HomeCS.html";
                break;
              case 400: // bad request
                document.getElementById("errormessage").textContent = message;
                break;
              case 401: // unauthorized
                document.getElementById("errormessage").textContent = message;
                break;
              case 412: // precondition failed
              	document.getElementById("errormessage").textContent = message;
              	break;
              case 500: // server error
            	document.getElementById("errormessage").textContent = message;
                break;
            }
          }
        }
      );
    } else {
    	 form.reportValidity();
    }
  });

})();