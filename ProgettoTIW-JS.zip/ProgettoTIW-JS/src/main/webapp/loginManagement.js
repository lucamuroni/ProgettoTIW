/**
 * Login management
 */

(function() { // avoid variables ending up in the global scope
	
	function validateEmail(elementValue) {      
   		var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
   		return emailPattern.test(elementValue); 
 	}
 	
 	function checkPasswords(pass1, pass2) {
		if (pass1 == pass2) {
			return true;
		} else {
			return false;
		}
	}
	
	//TODO: da finire
	function autoclick() {
	      var e = new Event("change");
	      var selector = "a[missionid='" + missionId + "']";
	      document.getElementById("test").scroll
	      if (anchorToClick) anchorToClick.dispatchEvent(e);
	}
 	
 	document.getElementById("test").addEventListener("change", function () {
    var style = this.value == 1 ? "block" : "none";
    document.getElementById("hidden_div").style.display = style;
	if(this.value == 1){
		document.getElementById("pwd3").required = true;
	}	     
	else{
		document.getElementById("pwd3").required = false;
	}
	});
	
	document.getElementById("registerbutton").addEventListener('click', (e) => {
	var form = e.target.closest("form");
	var input = document.getElementById("name1").value;
	var firstCheck = validateEmail(input);
	var pass1 = document.getElementById("pwd1").value;
	var pass2 = document.getElementById("pwd2").value;
	var secondCheck = checkPasswords(pass1, pass2);
	if (form.checkValidity()) {
		if (!firstCheck) {
			document.getElementById("errormessage1").textContent = "Incorrect mail syntax";
		} else if (!secondCheck){
			document.getElementById("errormessage1").textContent = "Passwords are different";
		} else {
			if (document.getElementById("test").value == 1) {
			makeCall("POST", 'AddEmployee', e.target.closest("form"),
        		function(x) {
         			if (x.readyState == XMLHttpRequest.DONE) {
            			var message = x.responseText;
            			switch (x.status) {
              				case 200:
            					sessionStorage.setItem('username', message);
                				window.location.href = "HomeEmployee.html";
                				break;
              				case 400: // bad request
              					
               					document.getElementById("errormessage1").textContent = message;
                				break;
              				case 401: // unauthorized
                				document.getElementById("errormessage1").textContent = message;
                				break;
             				case 412: // precondition failed
              					document.getElementById("errormessage1").textContent = message;
              					break;
              				case 500: // server error
            					document.getElementById("errormessage1").textContent = message;
                				break;
            			}
          			}
        		}
      		);
			} else {
			makeCall("POST", 'AddClient', e.target.closest("form"),
        		function(x) {
         			if (x.readyState == XMLHttpRequest.DONE) {
            			var message = x.responseText;
            			switch (x.status) {
              				case 200:
            					sessionStorage.setItem('username', message);
                				window.location.href = "HomeClient.html";
                				break;
              				case 400: // bad request
               					document.getElementById("errormessage1").textContent = message;
                				break;
              				case 401: // unauthorized
                				document.getElementById("errormessage1").textContent = message;
                				break;
             				case 412: // precondition failed
              					document.getElementById("errormessage1").textContent = message;
              					break;
              				case 500: // server error
            					document.getElementById("errormessage1").textContent = message;
                				break;
            			}
          			}
        		}
      		);
			}
		}
	} else {
    	 form.reportValidity();
    }
  	});
 	 
  	document.getElementById("loginbutton").addEventListener('click', (e) => {
	var form = e.target.closest("form");
	var input = document.getElementById("name").value;
	var bool = validateEmail(input);
	if (form.checkValidity()) {
		if(!bool) {
			document.getElementById("errormessage").textContent = "Incorrect mail format";
		} else {
			makeCall("POST", 'CheckLogin', e.target.closest("form"),
      			function(x) {
          			if (x.readyState == XMLHttpRequest.DONE) {
            			var message = x.responseText;
            			switch (x.status) {
              			case 200:
              				sessionStorage.setItem('username', input);  
              				//TODO: da risolvere: non va mai in HomeClient       
              				if (message === "client") {
								window.location.href = "HomeClient.html";
							} else {
								window.location.href = "HomeEmployee.html";
							}               
                			break;
              			case 400: // bad request
                			document.getElementById("errormessage").textContent = message;
                			break;
              			case 401: // unauthorized
                			document.getElementById("errormessage").textContent = message;
                			break;
              			case 412: // precondition failed
              				document.getElementById("errormessage").textContent = message;
              				break;
              			case 500: // server error
            				document.getElementById("errormessage").textContent = message;
                			break;
            			}
          			}
        		}
      		);
		}
	} else {
    	 form.reportValidity();
    }
  	});
})();