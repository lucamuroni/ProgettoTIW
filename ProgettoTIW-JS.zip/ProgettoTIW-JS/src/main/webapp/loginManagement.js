/**
 * Login management
 */

(function() { // avoid variables ending up in the global scope
	
	function ValidateEmail(elementValue) {      
   		var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
   		return emailPattern.test(elementValue); 
 	}
 	
 	function CheckPasswords(pass1, pass2) {
		if (pass1 == pass2) {
			return true;
		} else {
			return false;
		}
	}
	
	function StringComparison(a, b) {
    	a = a.toString(), b = b.toString();
    	for (var i=0,n=Math.max(a.length, b.length); i<n && a.charAt(i) === b.charAt(i); ++i);
    	if (i === n) return 0;
    	return a.charAt(i) > b.charAt(i) ? -1 : 1;
	}
	
	//TODO: da finire
	function Autoclick() {
  		const event = new Event("change");
  		const cb = document.getElementById("test");
  		cb.dispatchEvent(event);
  	}
 	
 	document.getElementById("test").addEventListener("change", function () {
    var style = this.value == 1 ? "block" : "none";
    document.getElementById("hidden_div").style.display = style;
	if(this.value == 1){
		document.getElementById("pwd3").required = true;
	}	     
	else{
		document.getElementById("pwd3").required = false;
	}
	});
	
	document.getElementById("registerbutton").addEventListener('click', (e) => {
	var form = e.target.closest("form");
	var input = document.getElementById("name1").value;
	var firstCheck = ValidateEmail(input);
	var pass1 = document.getElementById("pwd1").value;
	var pass2 = document.getElementById("pwd2").value;
	var secondCheck = CheckPasswords(pass1, pass2);
	if (form.checkValidity()) {
		if (!firstCheck) {
			document.getElementById("errormessage1").textContent = "Incorrect mail syntax";
		} else if (!secondCheck){
			document.getElementById("errormessage1").textContent = "Passwords are different";
		} else {
			if (document.getElementById("test").value == 1) {
			makeCall("POST", 'AddEmployee', e.target.closest("form"),
        		function(x) {
         			if (x.readyState == XMLHttpRequest.DONE) {
            			var message = x.responseText;
            			switch (x.status) {
              				case 200:
            					sessionStorage.setItem('username', message);
                				window.location.href = "HomeEmployee.html";
                				break;
              				case 400: // bad request
              					Autoclick();
               					document.getElementById("errormessage1").textContent = message;
                				break;
              				case 401: // unauthorized
              					Autoclick();
                				document.getElementById("errormessage1").textContent = message;
                				break;
             				case 412: // precondition failed
             					Autoclick();
              					document.getElementById("errormessage1").textContent = message;
              					break;
              				case 500: // server error
              					Autoclick();
            					document.getElementById("errormessage1").textContent = message;
                				break;
            			}
          			}
        		}
      		);
			} else {
			makeCall("POST", 'AddClient', e.target.closest("form"),
        		function(x) {
         			if (x.readyState == XMLHttpRequest.DONE) {
            			var message = x.responseText;
            			switch (x.status) {
              				case 200:
            					sessionStorage.setItem('username', message);
                				window.location.href = "HomeClient.html";
                				break;
              				case 400: // bad request
               					document.getElementById("errormessage1").textContent = message;
                				break;
              				case 401: // unauthorized
                				document.getElementById("errormessage1").textContent = message;
                				break;
             				case 412: // precondition failed
              					document.getElementById("errormessage1").textContent = message;
              					break;
              				case 500: // server error
            					document.getElementById("errormessage1").textContent = message;
                				break;
            			}
          			}
        		}
      		);
			}
		}
	} else {
			form.reportValidity();
    }
  	});
 	 
  	document.getElementById("loginbutton").addEventListener('click', (a) => {
	var form = a.target.closest("form");
	var input = document.getElementById("name").value;
	var bool = ValidateEmail(input);
	if (form.checkValidity()) {
		if(!bool) {
			document.getElementById("errormessage").textContent = "Incorrect mail format";
		} else {
			makeCall("POST", 'CheckLogin', a.target.closest("form"),
      			function(x) {
          			if (x.readyState == XMLHttpRequest.DONE) {
            			var message = x.responseText;
            			switch (x.status) {
              			case 200:
              				sessionStorage.setItem('username', input);  
              				var s = 'client\r\n'; 
              				if (StringComparison(s, message) == 0) {
								window.location.href = "HomeClient.html";
							} else {
								window.location.href = "HomeEmployee.html";
							}               
                			break;
              			case 400: // bad request
                			document.getElementById("errormessage").textContent = message;
                			break;
              			case 401: // unauthorized
                			document.getElementById("errormessage").textContent = message;
                			break;
              			case 412: // precondition failed
              				document.getElementById("errormessage").textContent = message;
              				break;
              			case 500: // server error
            				document.getElementById("errormessage").textContent = message;
                			break;
            			}
          			}
        		}
      		);
		}
	} else {
    	 form.reportValidity();
    }
  	});
})();