{
	let estimateDetails, estimatesList, /*wizard*/ pageOrchestrator = new PageOrchestrator();
	
	
	window.addEventListener("load", () => {
	    if (sessionStorage.getItem("username") == null) {
	      window.location.href = "index.html";
	    } else {
	      pageOrchestrator.start(); 
	      pageOrchestrator.refresh();
	    } 
	    
	}, false);
	
	// Constructors of view components
	
	function PersonalMessage(_username, messagecontainer) {
	    this.username = _username;
	    this.show = function() {
	      messagecontainer.textContent = this.username;
	    }
	}
	
	function EstimatesList(_alert, _listconteinerfree, _listcontainerbodyfree) {
	    this.alert = _alert;
	    this.listcontainerfree = _listconteinerfree;
	    this.listcontainerbodyfree = _listcontainerbodyfree;

	    this.reset = function() {
	      this.listcontainerfree.style.visibility = "hidden";
	    }

	    this.show = function(next) {
	      var self = this;
	      makeCall("GET", "GetEstimatesData", null,
	        function(req) {
	          if (req.readyState == 4) {
	            var message = req.responseText;
	            if (req.status == 200) {
	              var estimatesToShow = JSON.parse(req.responseText);
	              if (estimatesToShow.length == 0) {
	                self.alert.textContent = "No estimate yet!";
	                return;
	              }
	              self.update(estimatesToShow); // self visible by closure
	              if (next) next(); // show the default element of the list if present
	          } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
                  }
                  else {
	            self.alert.textContent = message;
	          }}
	        }
	      );
	    };


	    this.update = function(arrayEstimates) {
	      var row, estcell, linkcell, anchor;
	      this.listcontainerbodyfree.innerHTML = ""; // empty the table body
	      // build updated list
	      var self = this;
	      arrayEstimates.forEach(function(estimate) { // self visible here, not this
	        row = document.createElement("tr");
	        estcell = document.createElement("td");
	        estcell.textContent = estimate.idEstimate;
	        row.appendChild(estcell);
	        linkcell = document.createElement("td");
	        anchor = document.createElement("a");
	        linkcell.appendChild(anchor);
	        linkText = document.createTextNode("Show");
	        anchor.appendChild(linkText);
	        anchor.setAttribute('estimateid', estimate.idEstimate); // set a custom HTML attribute
	        anchor.addEventListener("click", (e) => {
	          // dependency via module parameter
	          estimateDetails.show(e.target.getAttribute("estimateid")); // the list must know the details container
	        }, false);
	        anchor.href = "#";
	        row.appendChild(linkcell);
	        self.listcontainerbodyfree.appendChild(row);
	      });
	      this.listcontainerfree.style.visibility = "visible";
	    }

	    this.autoclick = function(estimateId) {
	      var e = new Event("click");
	      var selector = "a[estimateid='" + estimateId + "']";
	      var anchorToClick =  // the first mission or the mission with id = missionId
	        (estimateId) ? document.querySelector(selector) : this.listcontainerbodyfree.querySelectorAll("a")[0];
	      if (anchorToClick) anchorToClick.dispatchEvent(e);
	    }
	  }
	  
	function EstimateDetails(options) {
	    this.alert = options['alert'];
	    this.detailcontainer = options['detailcontainer'];
	    this.client = options['client'];
	    this.product = options['product'];
	    this.price = options['price'];
	    this.option = options['option'];
	    this.optioncontainerfree = options['optioncontainerfree'];
	    this.optioncontainerbodyfree = options['optioncontainerbodyfree'];

	    this.show = function(estimateid) {
	      var self = this;
	      makeCall("GET", "GetEstimateDetailsData?estimateid=" + estimateid, null,
	        function(req) {
	          if (req.readyState == 4) {
	            var message = req.responseText;
	            if (req.status == 200) {
	              var estimate = JSON.parse(req.responseText);
	              self.update(estimate);
	              makeCall("GET", "GetEstimateOptionsData?estimateid=" + estimateid, null,
	        		function(rq) {
			  		  if (rq.readyState == 4) {
	             		var message = req.responseText;
	             		if (rq.status == 200) {
	              		  var options = JSON.parse(rq.responseText);
	              		  self.updateOptions(options);
	              		  
	            		} else if (rq.status == 403) {
                  		  window.location.href = rq.getResponseHeader("Location");
                  		  window.sessionStorage.removeItem('username');
                		} else {
	              		  self.alert.textContent = message;
	            		}
	          		  }
		    	 	}
		  		  );
	              self.detailcontainer.style.visibility = "visible";
	              self.optioncontainerfree.style.visibility = "visible";
	            } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
                } else {
	              self.alert.textContent = message;
	            }
	          }
	        }
	      );
	    };

	    this.reset = function() {
	      this.detailcontainer.style.visibility = "hidden";
	      this.optioncontainerfree.style.visibility = "hidden";
	    }

	    this.updateOptions = function(opts) {
		  this.optioncontainerbodyfree.innerHTML = "";
		  var row, optcell;
		  var self = this;
		  opts.forEach(function(opt) {
			 row = document.createElement("tr");
	         optcell = document.createElement("td");
	         optcell.textContent = opt.optionName;
	         row.appendChild(optcell);
	         self.optioncontainerbodyfree.appendChild(row);
		  });
		}
	  }
	
	
	function PageOrchestrator() {
		var alertContainer = document.getElementById("id_alert");
	    
	    this.start = function() {
	      personalMessage = new PersonalMessage(sessionStorage.getItem('username'),
	        document.getElementById("id_username"));
	      personalMessage.show();
	      
	      estimatesList = new EstimatesList(
	        alertContainer,
	        document.getElementById("id_listcontainerfree"),
	        document.getElementById("id_listcontainerbodyfree"));
	        
	      document.querySelector("a[href='Logout']").addEventListener('click', () => {
	        window.sessionStorage.removeItem('username');
	      })
	      
	      estimateDetails = new EstimateDetails({
	        alert: alertContainer,
	        detailcontainer: document.getElementById("id_detailcontainer"),
	        client: document.getElementById("id_client"),
	        product: document.getElementById("id_product"),
	        option: document.getElementById("id_option"),
	        optioncontainer: document.getElementById("id_optioncontainerfree"),
	        optioncontainerbody: document.getElementById("id_optioncontainerbodyfree")
	      });
	      
	   
	      wizard.registerEvents(this);
		};
		
		this.refresh = function(currentEstimate) { 
	      alertContainer.textContent = "";     
	      estimatesList.reset();
	      estimateDetails.reset();
	      estimatesList.show(function() {
	        estimatesList.autoclick(currentEstimate); 
	      });
	      wizard.reset();
	    };
	}
}