{
	let employeeEstimateDetails, employeeEstimatesList, estimateDetails, estimatesList, pageOrchestrator = new PageOrchestrator();
	
	window.addEventListener("load", () => {
	    if (sessionStorage.getItem("username") == null) {
	      window.location.href = "index.html";
	    } else {
	      pageOrchestrator.start(); 
	      pageOrchestrator.refresh();
	    } 
	    
	}, false);
	
	// Constructors of view components
	
	function PersonalMessage(_username, messagecontainer) {
	    this.username = _username;
	    this.show = function() {
	      messagecontainer.textContent = this.username;
	    }
	}
	
	//EMPLOYEEESTIMATE
	function EmployeeEstimatesList(_alert, _listconteiner, _listcontainerbody) {
	    this.alert = _alert;
	    this.listcontainer = _listconteiner;
	    this.listcontainerbody = _listcontainerbody;

	    this.reset = function() {
	      this.listcontainer.style.visibility = "hidden";
	    }

	    this.show = function(next) {
	      var self = this;
	      makeCall("GET", "GetEstimatesData", null,
	        function(req) {
	          if (req.readyState == 4) {
	            var message = req.responseText;
	            if (req.status == 200) {
	              var estimatesToShow = JSON.parse(req.responseText);
	              if (estimatesToShow.length == 0) {
	                self.alert.textContent = "No estimates priced!";
	                return;
	              }
	              self.update(estimatesToShow); // self visible by closure
	              if (next) next(); // show the default element of the list if present
	          } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
                  }
                  else {
	            self.alert.textContent = message;
	          }}
	        }
	      );
	    };


	    this.update = function(employeeArrayEstimates) {
	      var row, estcell, linkcell, anchor;
	      this.listcontainerbody.innerHTML = ""; // empty the table body
	      // build updated list
	      var self = this;
	      employeeArrayEstimates.forEach(function(estimate) { // self visible here, not this
	        row = document.createElement("tr");
	        estcell = document.createElement("td");
	        estcell.textContent = estimate.idEstimate;
	        row.appendChild(estcell);
	        linkcell = document.createElement("td");
	        anchor = document.createElement("a");
	        linkcell.appendChild(anchor);
	        linkText = document.createTextNode("Show");
	        anchor.appendChild(linkText);
	        anchor.setAttribute('estimateid', estimate.idEstimate); // set a custom HTML attribute
	        anchor.addEventListener("click", (e) => {
	          // dependency via module parameter
	          employeeEstimateDetails.show(e.target.getAttribute("estimateid")); // the list must know the details container
	        }, false);
	        anchor.href = "#";
	        row.appendChild(linkcell);
	        self.listcontainerbody.appendChild(row);
	      });
	      this.listcontainer.style.visibility = "visible";
	    }

	    this.autoclick = function(estimateId) {
	      var e = new Event("click");
	      var selector = "a[estimateid='" + estimateId + "']";
	      var anchorToClick = 
	        (estimateId) ? document.querySelector(selector) : this.listcontainerbody.querySelectorAll("a")[0];
	      if (anchorToClick) anchorToClick.dispatchEvent(e);
	    }
	  }
	  
	function EmployeeEstimateDetails(employeeOptions) {
	    this.alert = employeeOptions['alert'];
	    this.detailconteiner = employeeOptions['detailcontainer'];
	    this.client2 = employeeOptions['client2'];
	    this.product2 = employeeOptions['product2'];
	    this.price2 = employeeOptions['price2'];
	    this.option2 = employeeOptions['option2'];
	    this.optioncontainer = employeeOptions['optioncontainer'];
	    this.optioncontainerbody = employeeOptions['optioncontainerbody'];

	    this.show = function(estimateid) {
	      var self = this;
	      makeCall("GET", "GetEstimateDetailsData?estimateid=" + estimateid, null,
	        function(req) {
	          if (req.readyState == 4) {
	            var message = req.responseText;
	            if (req.status == 200) {
	              var estimate = JSON.parse(req.responseText);
	              self.update(estimate);
	              makeCall("GET", "GetEstimateOptionsData?estimateid=" + estimateid, null,
	        		function(rq) {
			  		  if (rq.readyState == 4) {
	             		var message = req.responseText;
	             		if (rq.status == 200) {
	              		  var options = JSON.parse(rq.responseText);
	              		  self.updateOptions(options);
	              		  
	            		} else if (rq.status == 403) {
                  		  window.location.href = rq.getResponseHeader("Location");
                  		  window.sessionStorage.removeItem('username');
                		} else {
	              		  self.alert.textContent = message;
	            		}
	          		  }
		    	 	}
		  		  );
	              self.detailconteiner.style.visibility = "visible";
	              self.optioncontainer.style.visibility = "visible";
	            } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
                } else {
	              self.alert.textContent = message;
	            }
	          }
	        }
	      );
	    };

	    this.reset = function() {
	      this.detailconteiner.style.visibility = "hidden";
	      this.optioncontainer.style.visibility = "hidden";
	    }

	    this.update = function(est) {
			this.client2.textContent = est.idClient;
	      	this.product2.textContent = est.idProduct;
	      	this.price2.textContent = est.price;
	    }
	    
	    this.updateOptions = function(opts) {
		  this.optioncontainerbody.innerHTML = "";
		  var row, optcell;
		  var self = this;
		  opts.forEach(function(opt) {
			 row = document.createElement("tr");
	         optcell = document.createElement("td");
	         optcell.textContent = opt.optionName;
	         row.appendChild(optcell);
	         self.optioncontainerbody.appendChild(row);
		  });
		}
	  }
	
	//FREEESTIMATE
	function EstimatesList(_alert, _listconteinerfree, _listcontainerbodyfree) {
	    this.alert = _alert;
	    this.listcontainerfree = _listconteinerfree;
	    this.listcontainerbodyfree = _listcontainerbodyfree;

	    this.reset = function() {
	      this.listcontainerfree.style.visibility = "hidden";
	    }

	    this.show = function(next) {
	      var self = this;
	      makeCall("GET", "GetFreeEstimatesData", null,
	        function(req) {
	          if (req.readyState == 4) {
	            var message = req.responseText;
	            if (req.status == 200) {
	              var estimatesToShow = JSON.parse(req.responseText);
	              if (estimatesToShow.length == 0) {
	                self.alert.textContent = "No free estimates!";
	                return;
	              }
	              self.update(estimatesToShow); // self visible by closure
	              if (next) next(); // show the default element of the list if present
	          } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
                  }
                  else {
	            self.alert.textContent = message;
	          }}
	        }
	      );
	    };


	    this.update = function(arrayEstimates) {
	      var row, estcell, linkcell, anchor;
	      this.listcontainerbodyfree.innerHTML = ""; // empty the table body
	      // build updated list
	      var self = this;
	      arrayEstimates.forEach(function(estimate) { // self visible here, not this
	        row = document.createElement("tr");
	        estcell = document.createElement("td");
	        estcell.textContent = estimate.idEstimate;
	        row.appendChild(estcell);
	        linkcell = document.createElement("td");
	        anchor = document.createElement("a");
	        linkcell.appendChild(anchor);
	        linkText = document.createTextNode("Show");
	        anchor.appendChild(linkText);
	        anchor.setAttribute('estimateid', estimate.idEstimate); // set a custom HTML attribute
	        anchor.addEventListener("click", (e) => {
	          // dependency via module parameter
	          estimateDetails.show(e.target.getAttribute("estimateid")); // the list must know the details container
	        }, false);
	        anchor.href = "#";
	        row.appendChild(linkcell);
	        self.listcontainerbodyfree.appendChild(row);
	      });
	      this.listcontainerfree.style.visibility = "visible";
	    }

	    this.autoclick = function(estimateId) {
	      var e = new Event("click");
	      var selector = "a[estimateid='" + estimateId + "']";
	      var anchorToClick = 
	        (estimateId) ? document.querySelector(selector) : this.listcontainerbodyfree.querySelectorAll("a")[0];
	      if (anchorToClick) anchorToClick.dispatchEvent(e);
	    }
	  }
	  
	function EstimateDetails(options) {
	    this.alert = options['alert'];
	    this.detailconteinerfree = options['detailcontainerfree'];
	    this.client = options['client'];
	    this.product = options['product'];
	    this.price = options['price'];
	    this.option = options['option'];
	    this.optioncontainerfree = options['optioncontainerfree'];
	    this.optioncontainerbodyfree = options['optioncontainerbodyfree'];
	    this.priceform = options['priceform'];
	    let chosenEstimate;

		//missionToReport = form.querySelector("input[type = 'hidden']").value;
	    //TODO: aggiungere modo per prendere estimate cliccato + aggiungere immagine nella scelta dei product in client
		this.registerEvent = function(orchestrator) {
	      this.priceform.querySelector("input[type='button']").addEventListener('click', (e) => {
	        var form = e.target.closest("form");
	        if (form.checkValidity()) {
	          var self = this;            
	          makeCall("POST", 'AddPrice?estimateId=' + chosenEstimate, form,
	            function(req) {
	              if (req.readyState == 4) {
	                var message = req.responseText;
	                if (req.status == 200) {
	                  orchestrator.refresh(message);
	                } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
                  }
                  else {
	                  self.alert.textContent = message;
	                }
	              }
	            }
	          );
	        } else {
	          form.reportValidity();
	        }
	      });
	    }

	    this.show = function(estimateid) {
		  chosenEstimate = estimateid;
	      var self = this;
	      makeCall("GET", "GetEstimateDetailsData?estimateid=" + estimateid, null,
	        function(req) {
	          if (req.readyState == 4) {
	            var message = req.responseText;
	            if (req.status == 200) {
	              var estimate = JSON.parse(req.responseText);
	              self.update(estimate);
	              makeCall("GET", "GetEstimateOptionsData?estimateid=" + estimateid, null,
	        		function(rq) {
			  		  if (rq.readyState == 4) {
	             		var message = req.responseText;
	             		if (rq.status == 200) {
	              		  var options = JSON.parse(rq.responseText);
	              		  self.updateOptions(options);
	              		  
	            		} else if (rq.status == 403) {
                  		  window.location.href = rq.getResponseHeader("Location");
                  		  window.sessionStorage.removeItem('username');
                		} else {
	              		  self.alert.textContent = message;
	            		}
	          		  }
		    	 	}
		  		  );
	              self.detailconteinerfree.style.visibility = "visible";
	              self.optioncontainerfree.style.visibility = "visible";
	            } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
                } else {
	              self.alert.textContent = message;
	            }
	          }
	        }
	      );
	    };

	    this.reset = function() {
	      this.detailconteinerfree.style.visibility = "hidden";
	      this.optioncontainerfree.style.visibility = "hidden";
	    }

	    this.update = function(e) {
			this.client.textContent = e.idClient;
	      	this.product.textContent = e.idProduct;
	    }
	    
	    this.updateOptions = function(opts) {
		  this.optioncontainerbodyfree.innerHTML = "";
		  var row, optcell;
		  var self = this;
		  opts.forEach(function(opt) {
			 row = document.createElement("tr");
	         optcell = document.createElement("td");
	         optcell.textContent = opt.optionName;
	         row.appendChild(optcell);
	         self.optioncontainerbodyfree.appendChild(row);
		  });
		}
	  }
	
	function PageOrchestrator() {
		var alertContainer = document.getElementById("id_alert");
	    
	    this.start = function() {
	      personalMessage = new PersonalMessage(sessionStorage.getItem('username'),
	        document.getElementById("id_username"));
	      personalMessage.show();
	      
	      estimatesList = new EstimatesList(
	        alertContainer,
	        document.getElementById("id_listcontainerfree"),
	        document.getElementById("id_listcontainerbodyfree"));
	        
	      employeeEstimatesList = new EmployeeEstimatesList(
	        alertContainer,
	        document.getElementById("id_listcontainer"),
	        document.getElementById("id_listcontainerbody"));
	        
	      document.querySelector("a[href='Logout']").addEventListener('click', () => {
	        window.sessionStorage.removeItem('username');
	      })
	      
	      estimateDetails = new EstimateDetails({
	        alert: alertContainer,
	        detailcontainerfree: document.getElementById("id_detailcontainerfree"),
	        client: document.getElementById("id_client"),
	        product: document.getElementById("id_product"),
	        option: document.getElementById("id_option"),
	        optioncontainerfree: document.getElementById("id_optioncontainerfree"),
	        optioncontainerbodyfree: document.getElementById("id_optioncontainerbodyfree"),
	        priceform: document.getElementById("id_priceform")
	      });
	      estimateDetails.registerEvent(this);
	      
	       employeeEstimateDetails = new EmployeeEstimateDetails({
	        alert: alertContainer,
	        detailcontainer: document.getElementById("id_detailcontainer"),
	        client2: document.getElementById("id_client2"),
	        product2: document.getElementById("id_product2"),
	        price2: document.getElementById("id_price2"),
	        option2: document.getElementById("id_option2"),
	        optioncontainer: document.getElementById("id_optioncontainer"),
	        optioncontainerbody: document.getElementById("id_optioncontainerbody")
	      });
	      
		  };
		  
		
		this.refresh = function(currentEstimate) { 
	      alertContainer.textContent = "";     
	      estimatesList.reset();
	      estimateDetails.reset();
	      employeeEstimatesList.reset();
	      employeeEstimateDetails.reset();
	      estimatesList.show(function() {
	        estimatesList.autoclick(currentEstimate); 
	      });
	      employeeEstimatesList.show(function() {
	        employeeEstimatesList.autoclick(currentEstimate); 
	      });
	    };
	}
}