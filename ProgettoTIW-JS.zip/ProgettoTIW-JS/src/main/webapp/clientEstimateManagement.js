{
	let estimateDetails, estimatesList, /*wizard*/ pageOrchestrator = new PageOrchestrator();
	
	/*function getAllProductsOptions() {
		makecall("GET", "GetProductsData", null, 
		function(req) {
			if (req.readyState == 4) {
	            var message = req.responseText;
	            if (req.status == 200) {
	              var productsToShow = JSON.parse(req.responseText);
	              for(var i = 0; i<producstToShow.lenght; i++)
	              {
					makecall("Get", "GetProductOptions?productsid="+i, null,
					function(x) {
						if (x.readyState == 4) {
	            			var message1 = req.responseText;
	            			if (req.status == 200) {
								//TODO: qui bisogna creare l'Array di opzioni
							}
						}
				  	});
	              }
	            } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
            	} else {
	            self.alert.textContent = message;
	        	}
	        }
	    });
	}*/
	
	window.addEventListener("load", () => {
	    if (sessionStorage.getItem("username") == null) {
	      window.location.href = "index.html";
	    } else {
	      pageOrchestrator.start(); 
	      pageOrchestrator.refresh();
	    } 
	    
	}, false);
	
	// Constructors of view components
	
	function PersonalMessage(_username, messagecontainer) {
	    this.username = _username;
	    this.show = function() {
	      messagecontainer.textContent = this.username;
	    }
	}
	
	function EstimatesList(_alert, _listcontainer, _listcontainerbody) {
	    this.alert = _alert;
	    this.listcontainer = _listcontainer;
	    this.listcontainerbody = _listcontainerbody;

	    this.reset = function() {
	      this.listcontainer.style.visibility = "hidden";
	    }

	    this.show = function(next) {
	      var self = this;
	      makeCall("GET", "GetEstimatesData", null,
	        function(req) {
	          if (req.readyState == 4) {
	            var message = req.responseText;
	            if (req.status == 200) {
	              var estimatesToShow = JSON.parse(req.responseText);
	              if (estimatesToShow.length == 0) {
	                self.alert.textContent = "No missions yet!";
	                return;
	              }
	              self.update(estimatesToShow); // self visible by closure
	              if (next) next(); // show the default element of the list if present
	          } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
                  }
                  else {
	            self.alert.textContent = message;
	          }}
	        }
	      );
	    };


	    this.update = function(arrayEstimates) {
	      var row, estcell, linkcell, anchor;
	      this.listcontainerbody.innerHTML = ""; // empty the table body
	      // build updated list
	      var self = this;
	      arrayEstimates.forEach(function(estimate) { // self visible here, not this
	        row = document.createElement("tr");
	        estcell = document.createElement("td");
	        estcell.textContent = estimate.idEstimate;
	        row.appendChild(estcell);
	        linkcell = document.createElement("td");
	        anchor = document.createElement("a");
	        linkcell.appendChild(anchor);
	        linkText = document.createTextNode("Show");
	        anchor.appendChild(linkText);
	        anchor.setAttribute('estimateid', estimate.idEstimate); // set a custom HTML attribute
	        anchor.addEventListener("click", (e) => {
	          // dependency via module parameter
	          estimateDetails.show(e.target.getAttribute("estimateid")); // the list must know the details container
	        }, false);
	        anchor.href = "#";
	        row.appendChild(linkcell);
	        self.listcontainerbody.appendChild(row);
	      });
	      this.listcontainer.style.visibility = "visible";
	    }

	    this.autoclick = function(estimateId) {
	      var e = new Event("click");
	      var selector = "a[estimateid='" + estimateId + "']";
	      var anchorToClick =  // the first mission or the mission with id = missionId
	        (estimateId) ? document.querySelector(selector) : this.listcontainerbody.querySelectorAll("a")[0];
	      if (anchorToClick) anchorToClick.dispatchEvent(e);
	    }

	  }
	  
	function EstimateDetails(options) {
	    this.alert = options['alert'];
	    this.detailcontainer = options['detailcontainer'];
	    this.employee = options['employee'];
	    this.product = options['product'];
	    this.price = options['price'];
	    this.option = options['option'];
	    this.optioncontainer = options['optioncontainer'];
	    this.optioncontainerbody = options['optioncontainerbody'];

	    this.show = function(estimateid) {
	      var self = this;
	      makeCall("GET", "GetEstimateDetailsData?estimateid=" + estimateid, null,
	        function(req) {
	          if (req.readyState == 4) {
	            var message = req.responseText;
	            if (req.status == 200) {
	              var estimate = JSON.parse(req.responseText);
	              self.update(estimate);
	              makeCall("GET", "GetEstimateOptionsData?estimateid=" + estimateid, null,
	        		function(rq) {
			  		  if (rq.readyState == 4) {
	             		var message = req.responseText;
	             		if (rq.status == 200) {
	              		  var options = JSON.parse(rq.responseText);
	              		  self.updateOptions(options);
	              		  
	            		} else if (rq.status == 403) {
                  		  window.location.href = rq.getResponseHeader("Location");
                  		  window.sessionStorage.removeItem('username');
                		} else {
	              		  self.alert.textContent = message;
	            		}
	          		  }
		    	 	}
		  		  );
	              self.detailcontainer.style.visibility = "visible";
	              self.optioncontainer.style.visibility = "visible";
	            } else if (req.status == 403) {
                  window.location.href = req.getResponseHeader("Location");
                  window.sessionStorage.removeItem('username');
                } else {
	              self.alert.textContent = message;
	            }
	          }
	        }
	      );
	    };

	    this.reset = function() {
	      this.detailcontainer.style.visibility = "hidden";
	      this.optioncontainer.style.visibility = "hidden";
	    }

	    this.update = function(e) {
		  if (e.idEmployee == 0) {
			this.employee.textContent = "Not assigned";
	        this.price.textContent = "Not assigned";
		  } else {
			this.employee.textContent = e.idEmployee;
			this.price.textContent = e.price;
		  }
	      this.product.textContent = e.idProduct;
	    }
	    
	    this.updateOptions = function(opts) {
		  this.optioncontainerbody.innerHTML = "";
		  var row, optcell;
		  var self = this;
		  opts.forEach(function(opt) {
			 row = document.createElement("tr");
	         optcell = document.createElement("td");
	         optcell.textContent = opt.optionName;
	         row.appendChild(optcell);
	         self.optioncontainerbody.appendChild(row);
		  });
		}
	  }
	
	function Wizard(alert, wizardform, selectprod, selectopt) {
	    // minimum date the user can choose, in this case now and in the future
	    this.wizard = wizardId;
	    this.alert = alert;
	    this.selectprod = selectprod;
	    this.selectopt = selectopt;

	    /*this.wizard.querySelector('input[type="date"]').setAttribute("min", formattedDate);

	    this.registerEvents = function(orchestrator) {
	      // Manage previous and next buttons
	      Array.from(this.wizard.querySelectorAll("input[type='button'].next,  input[type='button'].prev")).forEach(b => {
	        b.addEventListener("click", (e) => { // arrow function preserve the
	          // visibility of this
	          var eventfieldset = e.target.closest("fieldset"),
	            valid = true;
	          if (e.target.className == "next") {
	            for (i = 0; i < eventfieldset.elements.length; i++) {
	              if (!eventfieldset.elements[i].checkValidity()) {
	                eventfieldset.elements[i].reportValidity();
	                valid = false;
	                break;
	              }
	            }
	          }
	          if (valid) {
	            this.changeStep(e.target.parentNode, (e.target.className === "next") ? e.target.parentNode.nextElementSibling : e.target.parentNode.previousElementSibling);
	          }
	        }, false);
	      });

	      // Manage submit button
	      this.wizard.querySelector("input[type='button'].submit").addEventListener('click', (e) => {
	        var eventfieldset = e.target.closest("fieldset"),
	          valid = true;
	        for (i = 0; i < eventfieldset.elements.length; i++) {
	          if (!eventfieldset.elements[i].checkValidity()) {
	            eventfieldset.elements[i].reportValidity();
	            valid = false;
	            break;
	          }
	        }

	        if (valid) {
	          var self = this;
	          makeCall("POST", 'CreateMission', e.target.closest("form"),
	            function(req) {
	              if (req.readyState == XMLHttpRequest.DONE) {
	                var message = req.responseText; // error message or mission id
	                if (req.status == 200) {
	                  orchestrator.refresh(message); // id of the new mission passed
	                } else if (req.status == 403) {
                      window.location.href = req.getResponseHeader("Location");
                      window.sessionStorage.removeItem('username');
                  }
                  else {
	                  self.alert.textContent = message;
	                  self.reset();
	                }
	              }
	            }
	          );
	        }
	      });
	      // Manage cancel button
	      this.wizard.querySelector("input[type='button'].cancel").addEventListener('click', (e) => {
	        e.target.closest('form').reset();
	        this.reset();
	      });
	    };

	    this.reset = function() {
	      var fieldsets = document.querySelectorAll("#" + this.wizard.id + " fieldset");
	      fieldsets[0].hidden = false;
	      fieldsets[1].hidden = true;
	      fieldsets[2].hidden = true;

	    }

	    this.changeStep = function(origin, destination) {
	      origin.hidden = true;
	      destination.hidden = false;
	    }*/
	  }
	
	function PageOrchestrator() {
		var alertContainer = document.getElementById("id_alert");
	    
	    this.start = function() {
	      personalMessage = new PersonalMessage(sessionStorage.getItem('username'),
	        document.getElementById("id_username"));
	      personalMessage.show();
	      
	      estimatesList = new EstimatesList(
	        alertContainer,
	        document.getElementById("id_listcontainer"),
	        document.getElementById("id_listcontainerbody"));
	        
	      document.querySelector("a[href='Logout']").addEventListener('click', () => {
	        window.sessionStorage.removeItem('username');
	      })
	      
	      estimateDetails = new EstimateDetails({
	        alert: alertContainer,
	        detailcontainer: document.getElementById("id_detailcontainer"),
	        employee: document.getElementById("id_employee"),
	        product: document.getElementById("id_product"),
	        price: document.getElementById("id_price"),
	        option: document.getElementById("id_option"),
	        optioncontainer: document.getElementById("id_optioncontainer"),
	        optioncontainerbody: document.getElementById("id_optioncontainerbody")
	      });
	      
	      wizard = new Wizard({
		  alert: alertContainer,
		  wizardform: document.getElementById("id_createestimateform"),
		  selectprod: document.getElementById("id_selectprod"),
		  selectopt: document.getElementById("id_selectopt"),
		  });
	      wizard.registerEvents(this);
		};
		
		this.refresh = function(currentEstimate) { 
	      alertContainer.textContent = "";     
	      estimatesList.reset();
	      estimateDetails.reset();
	      estimatesList.show(function() {
	        estimatesList.autoclick(currentEstimate); 
	      });
	      wizard.reset();
	    };
	}
}