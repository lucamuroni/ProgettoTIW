package it.polimi.tiw.projects.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import it.polimi.tiw.projects.beans.Product;

public class ProductDAO {
	private Connection con;

	public ProductDAO(Connection connection) {
		this.con = connection;
	}

	public List<Product> getAllProducts() throws SQLException{
		List<Product> products = new ArrayList<Product>();
		String query = " SELECT * FROM product";
		ResultSet result = null;
		PreparedStatement pstatement = null;
		try {
			pstatement = con.prepareStatement(query);
			result = pstatement.executeQuery();	
			while (result.next()) {
				Product product = new Product();
				product.setIdProduct(result.getInt("idProduct"));
				product.setCodeProd(result.getString("codeProduct"));
				product.setProductName(result.getString("name"));
				product.setImage(result.getString("image"));
				products.add(product);
			}
		} catch (SQLException e) {
			throw e;
		} finally {
			try {
				if (result != null)
					result.close();
			} catch (SQLException e1) {
				throw e1;
			}
			try {
				if (pstatement != null)
					pstatement.close();
			} catch (SQLException e2) {
				throw e2;
			}
		}
		return products;
	}
	
	public Product findProductById(int prodId) throws SQLException{
		Product product = new Product();
		String query = " SELECT * FROM product WHERE idProduct = ? ";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, prodId);
			try (ResultSet result = pstatement.executeQuery();) {
				if (result.next()) {
					product.setIdProduct(result.getInt("idProduct"));
					product.setCodeProd(result.getString("codeProduct"));
					product.setProductName(result.getString("name"));
					product.setImage(result.getString("image"));
				}
			}
		}
		return product;
	}
	
	public String getName(int idProduct) throws SQLException {
		String query = "SELECT name FROM product WHERE idProduct = ? ";
		String name = null;
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, idProduct);
			try (ResultSet result = pstatement.executeQuery();) {
				if (result.next()) {
					name = result.getString("name");
				}
			}
		}
		return name;
	}
}
