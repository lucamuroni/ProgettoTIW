package it.polimi.tiw.projects.controllers;

import java.io.IOException;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.beans.Option;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.dao.AvailabilityDAO;
import it.polimi.tiw.projects.dao.EstimateDAO;
import it.polimi.tiw.projects.dao.OptionsEstimateDAO;
import it.polimi.tiw.projects.dao.UserDAO;
import it.polimi.tiw.projects.utils.ConnectionHandler;

@WebServlet("/CreateEstimate")
public class CreateEstimate extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;
	
	public CreateEstimate() {
		super();
	}
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// If the user is not logged in (not present in session) redirect to the login
		HttpSession s = request.getSession();
		if (s.isNew() || s.getAttribute("user") == null) {
			String loginpath = getServletContext().getContextPath() + "/index.html";
			response.sendRedirect(loginpath);
			return;
		}
		User u = (User) s.getAttribute("user");
		//Modificare da String ad ArrayList di String perch� ci possono essere pi� di un'opzione
		String[] opts = request.getParameterValues("options");	
		String prdId = request.getParameter("productId");
		if (opts == null || prdId == null) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing parameter for estimate creation");
			return;
		}
		
		int[] optionsId = new int[opts.length];
		int productId = 0;
		try {
			int i = 0;
			while(i < opts.length)
			{
				optionsId[i] = Integer.parseInt(opts[i]);
				i=i+1;
			}
			
		} catch (NumberFormatException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Bad option parameter in estimate creation");
			return;
		}
		try {
			productId = Integer.parseInt(prdId);
		} catch (NumberFormatException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Bad product parameter in estimate creation");
			return;
		}
		
		EstimateDAO estimateDao = new EstimateDAO(connection);
		OptionsEstimateDAO optsEstimateDao= new OptionsEstimateDAO(connection);
		AvailabilityDAO availabilityDao = new AvailabilityDAO(connection);
		boolean check = false;	
		int idEstimate = 0;
		//Controllo della presenza di options non permesse al prodotto scelto
		try {
			//Sempre fare modifica per ArrayList di opzioni ricevute
			List<Option> options = availabilityDao.findProductOptions(productId);
			for (int i = 0; i<optionsId.length; i++) {
				check = false;
				for (Option op : options) {
					if(op.getIdOption() == optionsId[i])
						check = true;
				}
				if (check == false) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Trying to create an estimate using an option not available for that product");
					return;
				}
			}

		} catch (SQLException e) {
			// throw new ServletException(e);
			response.sendError(HttpServletResponse.SC_BAD_GATEWAY, "Database failure");
		}
		
		try {
			//Sempre fare modifica per ArrayList di opzioni ricevute
			estimateDao.createEstimate(productId, u.getIdUser());
		} catch (SQLException e) {
			response.sendError(HttpServletResponse.SC_BAD_GATEWAY, "Failure in database estimate adding");
			return;	
		}
		
		try {
			//Sempre fare modifica per ArrayList di opzioni ricevute
			idEstimate = estimateDao.searchLastEstimate(u.getIdUser());
		} catch (SQLException e) {
			response.sendError(HttpServletResponse.SC_BAD_GATEWAY, "Failure in database estimate searching");
			return;	
		}
		
		try {
			//Sempre fare modifica per ArrayList di opzioni ricevute
			optsEstimateDao.addOptionsToEstimate(idEstimate, optionsId);
		} catch (SQLException e) {
			response.sendError(HttpServletResponse.SC_BAD_GATEWAY, "Failure in database OptionsEstimate adding");
			return;	
		}
		
		String ctxpath = getServletContext().getContextPath();
		String path = ctxpath + "/GoToHomeClient";
		response.sendRedirect(path);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

}
