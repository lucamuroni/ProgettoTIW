package it.polimi.tiw.projects.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import it.polimi.tiw.projects.beans.Estimate;
import it.polimi.tiw.projects.beans.Product;

public class EstimateDAO {
	private Connection con;
	
	public EstimateDAO(Connection connection) {
		this.con = connection;
	}
	
	public List<Estimate> findEstimatesByClientId(int clientId) throws SQLException {
		List<Estimate> clientEstimates = new ArrayList<Estimate>();
		String query = " SELECT * FROM estimate WHERE idClient = ?";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, clientId);
			try (ResultSet result = pstatement.executeQuery();) {
				while (result.next()) {
					Estimate estimate = new Estimate();
					estimate.setIdEstimate(result.getInt("idEstimate"));
					estimate.setIdClient(result.getInt("idClient"));
					estimate.setIdEmployee(result.getInt("idEmployee"));
					estimate.setIdProduct(result.getInt("idPrd"));
					estimate.setPrice(result.getInt("price"));
					clientEstimates.add(estimate);
				}
			}
		}
		return clientEstimates;
	}
	
	public Estimate findEstimateById(int estimateId) throws SQLException {
		Estimate estimate = null;
		String query = " SELECT * FROM estimate WHERE idEstimate = ?";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, estimateId);
			try (ResultSet result = pstatement.executeQuery();) {
				if (result.next()) {
					estimate = new Estimate();
					estimate.setIdEstimate(result.getInt("idEstimate"));
					estimate.setIdClient(result.getInt("idClient"));
					estimate.setIdEmployee(result.getInt("idEmployee"));
					estimate.setIdProduct(result.getInt("idPrd"));
					estimate.setPrice(result.getInt("price"));
				}
			}
		}
		return estimate;
	}
	
	/*public Product findProductNameByEstimate(int estimateId) throws SQLException {
		Product product = null;
		String query = " SELECT * FROM estimate AND product WHERE idEstimate = ? AND idPrd = idProduct";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, estimateId);
			try (ResultSet result = pstatement.executeQuery();) {
				if (result.next()) {
					product = new Product();
					product.setIdProduct(result.getInt("idPrd"));
					product.setCodeProd(result.getString("codeProduct"));
					product.setProductName(result.getString("name"));
					product.setImage(result.getString("image"));
				}
			}
		}
		return product;
	}*/
	
	public void addPriceEmployee(int employeeId, float price, int estimateId) throws SQLException {
			String query = "UPDATE estimate SET idEmployee = ?, price = ? WHERE (idEstimate = ?)";
			try (PreparedStatement pstatement = con.prepareStatement(query);) {
				pstatement.setInt(1, employeeId);
				pstatement.setFloat(2, price);
				pstatement.setInt(3, estimateId);
				pstatement.executeUpdate();
			}
		}
	
	public List<Estimate> findFreeEstimates() throws SQLException {
		Estimate estimate = null;
		List<Estimate> freeEstimates = new ArrayList<Estimate>();
		String query = "SELECT * FROM estimate WHERE price = 0";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			try (ResultSet result = pstatement.executeQuery();) {
				while (result.next()) {
					estimate = new Estimate();
					estimate.setIdEstimate(result.getInt("idEstimate"));
					estimate.setIdClient(result.getInt("idClient"));
					estimate.setIdEmployee(result.getInt("idEmployee"));
					estimate.setIdProduct(result.getInt("idPrd"));
					estimate.setPrice(result.getInt("price"));
					freeEstimates.add(estimate);
				}
			}
		}
		return freeEstimates;
	}
	
	public List<Estimate> findEstimatesByEmployeeId(int employeeId) throws SQLException {
		List<Estimate> clientEstimates = new ArrayList<Estimate>();
		String query = " SELECT * FROM estimate WHERE idEmployee = ?";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, employeeId);
			try (ResultSet result = pstatement.executeQuery();) {
				while (result.next()) {
					Estimate estimate = new Estimate();
					estimate.setIdEstimate(result.getInt("idEstimate"));
					estimate.setIdClient(result.getInt("idClient"));
					estimate.setIdEmployee(result.getInt("idEmployee"));
					estimate.setIdProduct(result.getInt("idPrd"));
					estimate.setPrice(result.getInt("price"));
					clientEstimates.add(estimate);
				}
			}
		}
		return clientEstimates;
	}
	
	public void createEstimate(int productId, int clientId) throws SQLException {
		String query = "INSERT into estimate (idClient, idPrd)   VALUES(?, ?)";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, clientId);
			pstatement.setInt(2, productId);
			pstatement.executeUpdate();
		}
		
		//NON FUNZIONA!!
		//TODO: Creare funzione private per recuperare id del preventivo appena creato
		
		
	}
	
	public int searchLastEstimate(int clientId) throws SQLException {
		int idEstimate = 0;
		String query = "SELECT MAX(idEstimate) AS id FROM estimate WHERE idClient = ? GROUP BY idClient";
		try (PreparedStatement pstatement = con.prepareStatement(query);) {
			pstatement.setInt(1, clientId);
			try (ResultSet result = pstatement.executeQuery();) {
				if (result.next()) {
					idEstimate = result.getInt("id");
				}
			}
		}
		return idEstimate;
	}
}
