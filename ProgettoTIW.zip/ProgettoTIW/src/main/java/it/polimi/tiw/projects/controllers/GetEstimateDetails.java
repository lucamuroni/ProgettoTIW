package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.beans.Estimate;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.beans.Option;
import it.polimi.tiw.projects.dao.EstimateDAO;
import it.polimi.tiw.projects.dao.OptionsEstimateDAO;
import it.polimi.tiw.projects.dao.ProductDAO;
import it.polimi.tiw.projects.dao.UserDAO;
import it.polimi.tiw.projects.utils.ConnectionHandler;

@WebServlet("/GetEstimateDetails")
public class GetEstimateDetails extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;

	public GetEstimateDetails() {
		super();
	}
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		Integer estimateId = null;
		try {
			estimateId = Integer.parseInt(request.getParameter("estimateId"));
		} catch (NullPointerException | NumberFormatException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Incorrect param values");
			return;
		}

		User user = (User) session.getAttribute("user");
		EstimateDAO estimateDAO = new EstimateDAO(connection);
		List<Estimate> estimates = null;
		if (user.getRole().equals("client")) {			
			try {
				estimates = estimateDAO.findEstimatesByClientId(user.getIdUser());
			} catch (SQLException e) {
				response.sendError(HttpServletResponse.SC_BAD_GATEWAY, "Failure in client's estimates database extraction");
				return;
			}
		} else {
			try {
				estimates = estimateDAO.findEstimatesByEmployeeId(user.getIdUser());
			} catch (SQLException e) {
				response.sendError(HttpServletResponse.SC_BAD_GATEWAY, "Failure in client's estimates database extraction");
				return;
			}
		}
		boolean check = false;
		for (Estimate est : estimates) {
			if (est.getIdEstimate() == estimateId) {
				check = true;
				break;
			}	
		}
		if (check == false) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "You don't have permission to see this estimate");
			return;
		}
		
		Estimate estimate = new Estimate();	
		try {
			estimate = estimateDAO.findEstimateById(estimateId);
			if (estimate == null) {
				response.sendError(HttpServletResponse.SC_NOT_FOUND, "Resource not found");
				return;
			}
		} catch (SQLException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failure in searching for estimates");
			return;
		}
		
		UserDAO userDao = new UserDAO(connection);
		String username = null;
		try {
			username = userDao.getUsername(estimate.getIdEmployee());
		} catch (SQLException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failure in searching for estimates");
			return;
		}
		
		ProductDAO prdDao = new ProductDAO(connection);
		String prdName = null;
		try {
			prdName = prdDao.getName(estimate.getIdProduct());
		} catch (SQLException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failure in searching for estimates");
			return;
		}
		
		List<Option> options = null;
		OptionsEstimateDAO optEstDao = new OptionsEstimateDAO(connection);
		try {
			options = optEstDao.findEstimateOptions(estimateId);
		} catch (SQLException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failure in searching options for estimate");
			return;
		}
		
		String path = "/WEB-INF/EstimateDetails.html";
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		ctx.setVariable("estimate", estimate);
		ctx.setVariable("options", options);
		ctx.setVariable("user", user);
		ctx.setVariable("username", username);
		ctx.setVariable("prdName", prdName);
		templateEngine.process(path, ctx, response.getWriter());
	}
	
	public void destroy() {
		try {
			ConnectionHandler.closeConnection(connection);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
