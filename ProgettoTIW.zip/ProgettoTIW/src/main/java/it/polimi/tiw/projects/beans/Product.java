package it.polimi.tiw.projects.beans;

public class Product {
	private int idProduct;
	private String codeProd;
	private String productName;
	private String image;
	
	public int getIdProduct() {
		return idProduct;
	}
	public String getCodeProd() {
		return codeProd;
	}
	public String getProductName() {
		return productName;
	}
	public String getImage() {
		return image;
	}
	public void setIdProduct(int idProduct) {
		this.idProduct = idProduct;
	}
	public void setCodeProd(String codeProd) {
		this.codeProd = codeProd;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setImage(String image) {
		this.image = image;
	}
}
