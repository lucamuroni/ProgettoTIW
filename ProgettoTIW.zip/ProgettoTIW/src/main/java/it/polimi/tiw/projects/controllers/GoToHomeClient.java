package it.polimi.tiw.projects.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.tiw.projects.beans.Estimate;
import it.polimi.tiw.projects.beans.Product;
import it.polimi.tiw.projects.beans.User;
import it.polimi.tiw.projects.dao.EstimateDAO;
import it.polimi.tiw.projects.dao.ProductDAO;
import it.polimi.tiw.projects.utils.ConnectionHandler;

@WebServlet("/GoToHomeClient")
public class GoToHomeClient extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private TemplateEngine templateEngine;
	
	public GoToHomeClient() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void init() throws ServletException {
		connection = ConnectionHandler.getConnection(getServletContext());
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession s = request.getSession();
		User u = (User) s.getAttribute("user");
		EstimateDAO estimateDao = new EstimateDAO(connection);
		
		List<Estimate> clientEstimates = null;
		try {
			clientEstimates = estimateDao.findEstimatesByClientId(u.getIdUser());
		} catch (SQLException e) {
			response.sendError(HttpServletResponse.SC_BAD_GATEWAY, "Failure in client's estimates database extraction");
			return;
		}
		
		/*List<Product> proEstimate = null;
		try {
			for (int i = 0; i < clientEstimates.size(); i++) {
			    	Estimate element = clientEstimates.get(i);
			    	proEstimate.add(estimateDao.findProductNameByEstimate(element.getIdProduct()));
			}
		} catch (SQLException e) {
			response.sendError(HttpServletResponse.SC_BAD_GATEWAY, "Failure in client's estimates database extraction");
			return;
		}*/
		
		
		ProductDAO productDao = new ProductDAO(connection);
		List<Product> products = null;
		try {
			products = productDao.getAllProducts();
		} catch (SQLException e) {
			response.sendError(HttpServletResponse.SC_BAD_GATEWAY, "Failure in client's estimates database extraction");
			return;
		}
		
		String path = "/WEB-INF/HomePageClient.html";
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		ctx.setVariable("estimates", clientEstimates);
		ctx.setVariable("products", products);
		//ctx.setVariable("proEstimate", proEstimate);
		templateEngine.process(path, ctx, response.getWriter());
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
