package it.polimi.tiw.projects.beans;

public class Estimate {
	private int idEstimate;
	private int idClient; 
	private int idEmployee;
	private int idProduct;
	private float price;
	
	public int getIdEstimate() {
		return idEstimate;
	}
	public int getIdClient() {
		return idClient;
	}
	public int getIdEmployee() {
		return idEmployee;
	}
	public int getIdProduct() {
		return idProduct;
	}
	public float getPrice() {
		return price;
	}
	public void setIdEstimate(int idEstimate) {
		this.idEstimate = idEstimate ;
	}
	public void setIdClient(int idClient) {
		this.idClient = idClient ;
	}
	public void setIdEmployee(int idEmployee) {
		this.idEmployee = idEmployee ;
	}
	public void setIdProduct(int idProduct) {
		this.idProduct = idProduct ;
	}
	public void setPrice(float price) {
		this.price = price ;
	}
}
